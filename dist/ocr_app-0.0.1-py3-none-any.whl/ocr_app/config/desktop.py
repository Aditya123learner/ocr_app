from frappe import _

def get_data():
	return [
		{
			"module_name": "ocr_app",
			"type": "module",
			"label": _("ocr_app")
		}
	]
