## ocr_app

auto data populate

#### License

MIT